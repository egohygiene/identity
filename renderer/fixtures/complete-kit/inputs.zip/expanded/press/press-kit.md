# Example Product Press Kit

This is a deterministic projection of approved public Identity source.

Source: https://example.invalid/example-product

Source digest: `00070c5765169a7a9cbb687b3f774a32d6fc155f8fc7dbd7aab67a4dba11ab3c`

## Short boilerplate

Example Product turns reviewed identity intent into reusable, deterministic artifacts.

Approval: `approve-press-short`

## Paragraph boilerplate

A supplied synthetic paragraph for complete Brand Kit handoff checks.

Approval: `approve-press-paragraph`

## Long boilerplate

Example Product is a local-first Identity workflow for maintainers who need approved tokens, assets, and guidance without splitting brand truth across hand-maintained folders.

Approval: `approve-press-long`

## Key facts

| Fact | Value |
| --- | --- |
| Availability | Open source and available to repository maintainers. |

## Links

- [Project repository](https://example.invalid/example-product) — repository

## Media contact

- **Media contact**: press@example.invalid — Please include the requested publication date and deadline.

## Team

### Example Maintainer

Project maintainer

Maintains the reviewed source and release boundaries for Example Product.


## Approved assets

### Primary mark

Use with the accompanying approved usage guidance.

[Download Primary mark](assets/example-product-mark.svg)

- Asset ID: `mark`
- License: `MIT` · approved
- Attribution: Copyright 2026 Example
- Creator: Example
- Origin method: first-party
- Source: https://example.invalid/source/mark
- Captured: 2026-08-21T11:00:00Z
- SHA-256: `b6d5becc4b80588f06199662463f17aaee45d069a135a8b6f6742805eaac20ad`
- Selection approval: `approve-press-mark`
- Safe zone: Keep one quarter of the mark width clear on every side.
- Minimum size: 16 CSS pixels for the standalone mark.
- Restriction: Do not stretch, rotate, or recolor outside approved tokens.


## Usage and legal guidance

- **dont · illustration**: Do not add illustration solely to fill space or obscure an incomplete explanation.
- **do · imagery**: Use imagery with approved licensing, source provenance, and context-specific alternative text.
- **do · localization**: Keep approved product names stable and request human review for uncovered language contexts.
- **do · mark**: Keep one quarter of the mark width clear on every side and use an approved high-contrast background.
- **dont · mark**: Do not stretch, rotate, crop, outline, or recolor the mark outside approved semantic tokens.
- **do · mascot**: Use the mascot as a supportive guide, never as the sole carrier of warnings or required instructions.
- **do · typography**: Use the licensed family, supported language coverage, and documented legibility constraints.
- **do · motion**: Pair every branded transition with its declared reduced-motion alternative.
- **do · color**: Choose semantic foreground and background pairs with their declared contrast intent.

Trademark: Example Product names and marks may be used only to identify the project without implying endorsement.

Copyright: Copyright 2026 Example. Source assets retain their recorded copyright and license terms.

Attribution: Preserve attribution from the governed provenance record when distributing an asset.

### Third-party asset notices

- **Example Product fixture assets** — `MIT`
  Attribution: Copyright 2026 Example

## Downloads

- [Press Kit data](press-kit.json) — Machine-readable, approved Press Kit projection.
- [Press Kit](press-kit.md) — Human-readable, approved Press and Media Kit.
- [Press Kit manifest](press-kit-manifest.json) — Source, file, and integrity record for this immutable package.
- [Press Kit checksums](SHA256SUMS) — SHA-256 checksums for the archive contents and manifest.
- [Complete Press Kit archive](press-kit.zip) — Versioned offline archive of approved Press and Media Kit materials.

This projection includes only approved public records. It does not authorize publication, alter source facts, or imply endorsement.
